# `@kiki-dsh/im-bridge-core`

This package is the host-independent IM session bridge extracted mechanically from the Kiki donor implementation in `packages/kap-server/src/services/imSession` and its pure routing/history helpers. It is the single authority for IM binding identity and ownership, group wake rules, deduplication and cursors, attachment routing, streaming replies, interaction ticketing, listener sharing/reanchoring, outbox delivery receipts, cancellation, and bounded shutdown.

The package contains no Kiki dependency-injection integration, hub adapter, OneBot host I/O, credential storage implementation, session runtime, or platform transport. It includes the provider setup catalog and setup flows; hosts supply `ImSetupOperations` for provider URLs and exchanges, persist credentials through the supplied save callback, and own external I/O. Hosts also provide the explicit `ImSessionPorts`, `ImAdapterFactory`, and `ImSessionAdapter` contracts. `ImSessionBridgeOptions.onChanged` is invoked after a committed state save for host-side observation; observer failures are isolated from the save.

## Use

Install the package dependencies in this directory, then run:

```sh
npm install
npm run build
npm test
```

The public entry point exports `ImSessionBridge`, `ImIdentityAlreadyBoundError`, `ImSessionSetup`, `ImSetupOperations`, `ImSessionPorts`, adapter contracts, zod schemas and inferred types, routing helpers, history and paste helpers, `joinDeliveries`, and the fake adapter.

## Donor and license

Behavior is a host-independent extraction of the Kiki/NB implementation. The package retains the Moonshot AI MIT notice in `LICENSE`; downstream hosts must preserve that notice when redistributing substantial portions.
