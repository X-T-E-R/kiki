# Direct URL acquisition dependencies

Direct URL acquisition uses **guarded-fetch 0.1.5** unchanged, from [vercel-labs/guarded-fetch](https://github.com/vercel-labs/guarded-fetch), licensed under Apache-2.0. Its complete upstream license, including the Vercel copyright notice, is reproduced in `LICENSES/guarded-fetch.txt`. The 0.1.5 npm distribution contains no separate NOTICE file.

The pinned runtime dependencies of guarded-fetch are **Undici 7.30.0** ([nodejs/undici](https://github.com/nodejs/undici), MIT) and **ipaddr.js 2.2.0** ([whitequark/ipaddr.js](https://github.com/whitequark/ipaddr.js), MIT). Their upstream licenses are reproduced in `LICENSES/undici.txt` and `LICENSES/ipaddr.js.txt`.

These packages remain external dependencies of nb-search. Distributors that bundle them must retain their licenses and attribution. nb-search's adapter maps existing errors, deadlines and partial-byte results; it does not modify the upstream packages. HTML main-body extraction continues to use Defuddle and linkedom.
