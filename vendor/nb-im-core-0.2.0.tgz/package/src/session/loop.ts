import type { SessionAdapter, SessionRunState } from './contract.ts';
import { unshareSession } from './registry.ts';

export function createSessionRun(key: string, adapter: SessionAdapter) {
  let state: SessionRunState = 'idle';
  let ready: Promise<void> | undefined;
  let resolveReady: (() => void) | undefined;
  let task: Promise<void> | undefined;
  let controller: AbortController | undefined;
  const opened = (): void => {
    resolveReady?.();
    resolveReady = undefined;
  };
  return {
    get state(): SessionRunState { return state; },
    set state(next: SessionRunState) {
      state = next;
      if (next === 'running' || next === 'conflict' || next === 'auth_expired' || next === 'stopped') opened();
    },
    start(body: (signal: AbortSignal) => Promise<void>): Promise<void> {
      if (state === 'stopped') throw new Error('session_stopped');
      if (state === 'conflict' || state === 'auth_expired') return Promise.resolve();
      if (ready) return ready;
      controller = new AbortController();
      state = 'starting';
      ready = new Promise((resolve) => { resolveReady = resolve; });
      const signal = controller.signal;
      task = body(signal).then(() => undefined, () => undefined).finally(() => {
        if (state !== 'conflict' && state !== 'auth_expired' && state !== 'stopped') state = 'stopped';
        opened();
        if (state === 'stopped') unshareSession(key, adapter);
      });
      return ready;
    },
    async stop(): Promise<void> {
      if (!task) {
        state = 'stopped';
        unshareSession(key, adapter);
        return;
      }
      controller?.abort();
      await task;
      state = 'stopped';
      unshareSession(key, adapter);
    },
  };
}
