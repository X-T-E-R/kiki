import { Readable } from 'node:stream';
import * as lark from '@larksuiteoapi/node-sdk';
import type { FeishuConnection, FeishuRequest, FeishuResponse } from './contract.ts';
import { abortError, isAbort } from './contract.ts';

const RESOURCE_CAP = 100 * 1024 * 1024;
type FileType = 'opus' | 'mp4' | 'pdf' | 'doc' | 'xls' | 'ppt' | 'stream';
const FILE_TYPES = new Set<string>(['opus', 'mp4', 'pdf', 'doc', 'xls', 'ppt', 'stream']);

function classify(error: unknown): 'auth' | 'conflict' | 'transport' {
  const text = error instanceof Error ? `${error.name}\n${error.message}` : '';
  if (/app secret|app_secret|invalid app|unauthorized|\b401\b|99991663|99991664/iu.test(text)) return 'auth';
  if (/conflict|already online|duplicate connection/iu.test(text)) return 'conflict';
  return 'transport';
}
async function readBounded(stream: Readable): Promise<FeishuResponse> {
  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of stream) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk as Uint8Array);
    total += bytes.length;
    if (total > RESOURCE_CAP) {
      stream.destroy();
      return { ok: false, too_large: true };
    }
    chunks.push(bytes);
  }
  return { ok: true, bytes: Buffer.concat(chunks) };
}

/** Enterprise self-built Feishu long connection. SDK errors are classified and not rethrown. */
export function createFeishuSdkConnection(input: { appId: string; appSecret: string }): FeishuConnection {
  const client = new lark.Client({
    appId: input.appId, appSecret: input.appSecret, appType: lark.AppType.SelfBuild,
    domain: lark.Domain.Feishu, loggerLevel: lark.LoggerLevel.error,
  });
  return {
    open(handlers, signal) {
      if (signal.aborted) return Promise.resolve({ ok: false, reason: 'transport' });
      return new Promise((resolve) => {
        let settled = false;
        let ready = false;
        const finish = (result: { ok: true } | { ok: false; reason: 'auth' | 'conflict' | 'transport' }): void => {
          if (settled) return;
          settled = true;
          ready = result.ok;
          resolve(result);
        };
        const ws = new lark.WSClient({
          appId: input.appId, appSecret: input.appSecret, domain: lark.Domain.Feishu,
          loggerLevel: lark.LoggerLevel.error,
          onReady: () => finish({ ok: true }),
          onError: (error) => {
            if (ready || settled) handlers.onDisconnect();
            else finish({ ok: false, reason: classify(error) });
          },
        });
        const dispatcher = new lark.EventDispatcher({ loggerLevel: lark.LoggerLevel.error });
        dispatcher.register({
          'im.message.receive_v1': (data) => handlers.onMessage(data),
          'card.action.trigger': (data: unknown) => handlers.onCardAction(data),
        } as Parameters<lark.EventDispatcher['register']>[0]);
        const started = ws.start({ eventDispatcher: dispatcher });
        void started.then(() => finish({ ok: true }), (error: unknown) => {
          if (!settled) finish({ ok: false, reason: classify(error) });
        });
        signal.addEventListener('abort', () => {
          ws.close({ force: true });
          if (settled) handlers.onDisconnect();
          else finish({ ok: false, reason: 'transport' });
        }, { once: true });
      });
    },
    send: (request, signal) => dispatch(client, request, signal),
  };
}
async function dispatch(client: lark.Client, request: FeishuRequest, signal: AbortSignal): Promise<FeishuResponse> {
  if (signal.aborted) throw abortError();
  try {
    if (request.op === 'create_message') {
      const response = await client.im.message.create({
        data: { receive_id: request.chat_id ?? '', msg_type: request.msg_type ?? 'text', content: request.content ?? '' },
        params: { receive_id_type: 'chat_id' },
      });
      const messageId = response.data?.message_id;
      return { ok: response.code === 0 || (response.code === undefined && typeof messageId === 'string'),
        ...(messageId ? { message_id: messageId } : {}), ...(response.code === undefined ? {} : { code: response.code }) };
    }
    if (request.op === 'update_message') {
      const response = await client.im.message.update({
        data: { msg_type: request.msg_type ?? 'text', content: request.content ?? '' },
        path: { message_id: request.message_id ?? '' },
      });
      return { ok: response.code === 0 || response.code === undefined,
        ...(request.message_id ? { message_id: request.message_id } : {}),
        ...(response.code === undefined ? {} : { code: response.code }) };
    }
    if (request.op === 'upload_image') {
      const response = await client.im.image.create({
        data: { image_type: 'message', image: Buffer.from(request.bytes ?? new Uint8Array()) },
      });
      return { ok: typeof response?.image_key === 'string', ...(response?.image_key ? { key: response.image_key } : {}) };
    }
    if (request.op === 'upload_file') {
      const fileType = request.file_type ?? '';
      if (!FILE_TYPES.has(fileType)) return { ok: false };
      const response = await client.im.file.create({
        data: { file_type: fileType as FileType, file_name: request.file_name ?? 'file',
          file: Buffer.from(request.bytes ?? new Uint8Array()) },
      });
      return { ok: typeof response?.file_key === 'string', ...(response?.file_key ? { key: response.file_key } : {}) };
    }
    const response = await client.im.messageResource.get({
      params: { type: request.resource_type ?? 'file' },
      path: { message_id: request.message_id ?? '', file_key: request.resource_key ?? '' },
    });
    return await readBounded(response.getReadableStream());
  } catch (error) {
    if (signal.aborted || isAbort(error)) throw abortError();
    return { ok: false };
  }
}
